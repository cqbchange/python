# 'https://kns-cnki-net-443.webvpn.scu.edu.cn/kcms2/article/abstract?v=lwcs1eIaudiGXv1ef_t1WcHtPhiw7jKlOApCXTwyNPqWbNaUalcf_0F2djenKEJtfnO6zPMyjje45uvKDx68ZbLXaM5RWcs4nvWCxrCRUVOrg4vT-kj36IvZaeUovbcw8ehrZEH1YurigmiIo0C1gBK4IfLHVb9KS8in6XO1YuEAIdJzXEG9notFCtQ-Mm1C&uniplatform=NZKPT&language=CHS'
# from dns.query import https
#
# url = 'https://bar-cnki-net-443.webvpn.scu.edu.cn/bar/download/order?id=Pmp%2F5es3RB81cmauPwpbvsPMJcfwHgIZAnUyOJG6KdpfnxH0ifbNup32DgGqxCY8MQeBatpLYQMywTa1zO36VEX2BAgiZH%2FWZnGL%2Fmn%2FQ0N7b5mY%2FmsIpB5E%2FKF94iQVwddxEU3rL3oTHoiWc6PitFK57xT%2B8LhM%2BfEqYWvBGm0igmLMld3nSvbU4a5%2BOkNaUlSU0HSLnl9m7MwOtW%2FIk7%2FMomsVGXE1DgcT921ylDtlgv7q8C%2BP7FPVW3hwYPcqveGzrp%2B41EH7caBaJ8FVkg%3D%3D'
# headers = {
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
# }
import requests


headers = {
    "authority": "kns-cnki-net-443.webvpn.scu.edu.cn",
    "accept": "*/*",
    "accept-language": "zh,zh-CN;q=0.9,en;q=0.8,de;q=0.7",
    "cache-control": "no-cache",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "$cookie": "Ecp_notFirstLogin=ywTaz2; _webvpn_key=eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiMjAyMjcyMTIiLCJncm91cHMiOls2MSw1OV0sImlhdCI6MTc0MzY1MDYzNiwiZXhwIjoxNzQzNzM3MDM2fQ.Wlde3_WLavQbxpG1V9XRZniKMlUIuIolqD1TQI-H9oQ; webvpn_username=20227212%7C1743650636%7Ce51876bdb0acd04098c287c220c4bfbe9e78ab89; SID_sug=018108; Ecp_ClientId=f250403112400383638; Ecp_session=1; SID_kns_new=kns018107; KNS2COOKIE=1743650653.128.31795.724648|b25e41a932fd162af3b8c5cff4059fc3; knsadv-searchtype=%7B%22BLZOG7CK%22%3A%22gradeSearch%2CmajorSearch%22%2C%22MPMFIG1A%22%3A%22gradeSearch%2CmajorSearch%2CsentenceSearch%22%2C%22T2VC03OH%22%3A%22gradeSearch%2CmajorSearch%22%2C%22JQIRZIYA%22%3A%22gradeSearch%2CmajorSearch%2CsentenceSearch%22%2C%22S81HNSV3%22%3A%22gradeSearch%22%2C%22YSTT4HG0%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22ML4DRIDX%22%3A%22gradeSearch%2CmajorSearch%22%2C%22WQ0UVIAA%22%3A%22gradeSearch%2CmajorSearch%22%2C%22VUDIXAIY%22%3A%22gradeSearch%2CmajorSearch%22%2C%22NN3FJMUV%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22LSTPFY1C%22%3A%22gradeSearch%2CmajorSearch%2CsentenceSearch%22%2C%22HHCPM1F8%22%3A%22gradeSearch%2CmajorSearch%22%2C%22OORPU5FE%22%3A%22gradeSearch%2CmajorSearch%22%2C%22WD0FTY92%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22BPBAFJ5S%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22EMRPGLPA%22%3A%22gradeSearch%2CmajorSearch%22%2C%22PWFIRAGL%22%3A%22gradeSearch%2CmajorSearch%2CsentenceSearch%22%2C%22U8J8LYLV%22%3A%22gradeSearch%2CmajorSearch%22%2C%22R79MZMCB%22%3A%22gradeSearch%22%2C%22J708GVCE%22%3A%22gradeSearch%2CmajorSearch%22%2C%22HR1YT1Z9%22%3A%22gradeSearch%2CmajorSearch%22%2C%22JUP3MUPD%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22NLBO1Z6R%22%3A%22gradeSearch%2CmajorSearch%22%2C%22RMJLXHZ3%22%3A%22gradeSearch%2CmajorSearch%2CsentenceSearch%22%2C%221UR4K4HZ%22%3A%22gradeSearch%2CmajorSearch%2CauthorSearch%2CsentenceSearch%22%2C%22NB3BWEHK%22%3A%22gradeSearch%2CmajorSearch%22%2C%22XVLO76FD%22%3A%22gradeSearch%2CmajorSearch%22%7D; Ecp_session=1; SID_restapi=kns018110; Ecp_LoginStuts={\"IsAutoLogin\":false,\"UserName\":\"XN0015\",\"ShowName\":\"%e5%9b%9b%e5%b7%9d%e5%a4%a7%e5%ad%a6%e5%9b%be%e4%b9%a6%e9%a6%86\",\"UserType\":\"bk\",\"BUserName\":\"\",\"BShowName\":\"\",\"BUserType\":\"\",\"r\":\"ywTaz2\",\"Members\":null}; c_m_LinID=LinID=WEEvREcwSlJHSldSdmVpZ0doOFdTQ1hSazdJVm9zSnF6SjRQZFFiR2VpND0=$9A4hF_YAuvQ5obgVAqNKPCYcEjKensW4IQMovwHtwkF4VYPoHbKxJw\\u0021\\u0021&ot=04%2f03%2f2025%2014%3a03%3a09; LID=WEEvREcwSlJHSldSdmVpZ0doOFdTQ1hSazdJVm9zSnF6SjRQZFFiR2VpND0=$9A4hF_YAuvQ5obgVAqNKPCYcEjKensW4IQMovwHtwkF4VYPoHbKxJw\\u0021\\u0021; c_m_expire=2025-04-03%2014%3a03%3a09; Ecp_LoginStuts={\"IsAutoLogin\":false,\"UserName\":\"XN0015\",\"ShowName\":\"%E5%9B%9B%E5%B7%9D%E5%A4%A7%E5%AD%A6%E5%9B%BE%E4%B9%A6%E9%A6%86\",\"UserType\":\"bk\",\"BUserName\":\"\",\"BShowName\":\"\",\"BUserType\":\"\",\"r\":\"ywTaz2\",\"Members\":[]}; LID=WEEvREcwSlJHSldSdmVpZ0doOFdTQ1hSazdJVm9zSnF6SjRQZFFiR2VpND0=$9A4hF_YAuvQ5obgVAqNKPCYcEjKensW4IQMovwHtwkF4VYPoHbKxJw\\u0021\\u0021; dsorders=DFR; searchTimeFlags=1; dsortypes=cur%20DESC; dblang=both; c_m_LinID=LinID=WEEvREcwSlJHSldSdmVpZ0doOFdTQ1hSazdJVm9zSnF6SjRQZFFiR2VpND0=$9A4hF_YAuvQ5obgVAqNKPCYcEjKensW4IQMovwHtwkF4VYPoHbKxJw\\u0021\\u0021&ot=04%2F03%2F2025%2014%3A18%3A33; c_m_expire=2025-04-03%2014%3A18%3A33; tfstk=g_tKSlNNqfc31ljmxDggqX6KQfMio3peQBJbq_f3PCd9OCqhRXJow0CMseqkd_6111p2-YWlqUL9FQzhPvlzVFdWs6sHE621N1OX-U0FKYBWeIE3-Qfk60IejeqltXSJFIj-ijmmmpJFbgGmi3HBgWjfdz67Zww1CgXJl94AepJF4RJuFKnDL7FOaKpCVQs_ftBVVTaQAAe1e1ZCFk671ABP1g6QVua1C9XbAy1WNdMOU115VwGWLbC_d_qJlxSri2zRmuZWX9Qsop1szCt1p_1vdHE7VYWdJs9C6j-nEe76UaKzUuQJdERPhBNIw_-9CHTXGf4hOEBJnUpIAlsHYpTfPnGzPpSh9GtBk8ZWBMCWi97Y9fCXYdtVfNmjHdtwtp-9E8i5IIf6LHs-cxSdA6sOQ3caA_L6PHbF4WGRahp6AUIzUnxxLHFcMT4IBAUzzw6aZYtSDKp8O0WOivn8zz7ZQOCmBAUzzw6NBsDK9zzP7A5..",
    "origin": "https://kns-cnki-net-443.webvpn.scu.edu.cn",
    "pragma": "no-cache",
    "referer": "https://kns-cnki-net-443.webvpn.scu.edu.cn/kns8s/defaultresult/index?crossids=YSTT4HG0%2CLSTPFY1C%2CJUP3MUPD%2CMPMFIG1A%2CWQ0UVIAA%2CBLZOG7CK%2CPWFIRAGL%2CEMRPGLPA%2CNLBO1Z6R%2CNN3FJMUV&korder=SU&kw=%E7%94%9F%E8%82%B2%E5%8A%9B%E4%BF%9D%E5%AD%98",
    "sec-ch-ua": "\"Not A(Brand\";v=\"99\", \"Google Chrome\";v=\"121\", \"Chromium\";v=\"121\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "x-requested-with": "XMLHttpRequest"
}
url = "https://kns-cnki-net-443.webvpn.scu.edu.cn/kcms2/article/abstract?v=lwcs1eIaudiGXv1ef_t1WcHtPhiw7jKlOApCXTwyNPqWbNaUalcf_0F2djenKEJtfnO6zPMyjje45uvKDx68ZbLXaM5RWcs4nvWCxrCRUVOrg4vT-kj36IvZaeUovbcw8ehrZEH1YurigmiIo0C1gBK4IfLHVb9KS8in6XO1YuEAIdJzXEG9notFCtQ-Mm1C&uniplatform=NZKPT&language=CHS'"
response = requests.post(url, headers=headers)

print(response.text)
print(response)